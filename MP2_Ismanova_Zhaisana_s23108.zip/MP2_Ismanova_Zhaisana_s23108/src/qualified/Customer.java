package qualified;

import java.util.Map;
import java.util.TreeMap;

public class Customer {

    private String name;
    private Map<String, Country> countriesQualif = new TreeMap<>(); //impl. assoc. card. 1
                                                                   //countryCode is the key (qualif), country is value
    public Customer(String name) {
        if (name == null || name.isEmpty()) throw new IllegalArgumentException("Name required");
        this.name = name;
    }

    public void addCountriesQualif(Country newCountry) { //add country using its countryCode as qualifier
        if (!countriesQualif.containsKey(newCountry.getCountryCode())) {
            countriesQualif.put(newCountry.getCountryCode(), newCountry);
            newCountry.addCustomer(this); //updates reverse association
        }
    }

    public Country findCountriesQualif(String countryCode) //find country using its countryCode as qualifier
    {
        if (!countriesQualif.containsKey(countryCode)) {
            throw new IllegalArgumentException("Country not found: " + countryCode);
        }

        return countriesQualif.get(countryCode);
    }
    public void removeCountriesQualif(String countryCode)  { //remove country and update reverse association

        Country country = findCountriesQualif(countryCode);

        countriesQualif.remove(countryCode);

        // Remove returning connection
        country.removeCustomer(this);
    }

    public double calculateShippingCost(String countryCode) { //returns the shipping cost for the given country
        return findCountriesQualif(countryCode).getBaseDeliveryPrice();
    }

    @Override
    public String toString() {
        return "Customer " + name;
    }
}

