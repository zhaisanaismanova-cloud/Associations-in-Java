package qualified;

import java.util.ArrayList;
import java.util.List;


public class Country {

    private String countryCode;
    private String countryName;
    private double baseDeliveryPrice;
    private List<Customer> customers = new ArrayList<>(); //impl. assoc. card. *

    public Country(String countryCode,String countryName, double baseDeliveryPrice) {

        if (countryCode == null || countryCode.isBlank()
                || countryCode.length() != 2) {
            throw new IllegalArgumentException("Country code required/invalid");
        }
       if (countryName == null || countryName.isBlank()){
           throw new IllegalArgumentException("Country name required");
       }
        if (baseDeliveryPrice < 0)
            throw new IllegalArgumentException("Invalid base delivery price");
        this.countryCode = countryCode;
        this.countryName = countryName;
        this.baseDeliveryPrice = baseDeliveryPrice;
    }

   public void addCustomer(Customer customer) { //add customer to this country without duplicate
            if (!customers.contains(customer)) {
               customers.add(customer);
           }
       }
   public void removeCustomer(Customer customer) { //removes cutomer from reverse association
        customers.remove(customer);

   }
   public List<Customer> getCustomers() { return new ArrayList<>(customers); } //find customers in this country, return copy of customers list
   public String getCountryCode() { return countryCode; }
    public String getCountryName() { return countryName; }
    public double getBaseDeliveryPrice() { return baseDeliveryPrice; }


    @Override
    public String toString() {
        return "Country: " + countryName +
        ", code: " + countryCode +
                ", delivery price: " + baseDeliveryPrice;
    }

}
