package binary;

import java.util.ArrayList;
import java.util.List;

public class Game {

        private String name;
        private String genre;
        private int releaseYear;
        private List<GameCharacter> characters = new ArrayList<>() ; //impl. assoc. card. *


    public Game(String name, String genre, int releaseYear) { //constructor
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Name required");
        }
        if (genre == null || genre.isEmpty()) {
            throw new IllegalArgumentException("Genre required");
        }
         if (releaseYear < 1990 || releaseYear > 2026) {
             throw new IllegalArgumentException("Invalid release year");
         }
        this.name = name;
        this.genre = genre;
        this.releaseYear = releaseYear;
    }

    public void addCharacter(GameCharacter character) { //add char and establish reverse connection
        if (character == null){
            throw new IllegalArgumentException("Character required");
        }
        if (character.getGame() != this){ //if already associated with another game then,
            character.setGame(this);      //change it using setGame
                                          //prevents infinite recursion
        }
        else if (!characters.contains(character)) { //elseif, add it to this game list if not already there
            characters.add(character);
        }
    }

    public void removeCharacter(GameCharacter character) { //remove character from game list

        if (character == null) {
            throw new IllegalArgumentException("Character cannot be null");
        }

        if (character.getGame() == this) { //character must first be transferred to another game
            throw new IllegalStateException(  // to prevent breaking the mandatory 1 * association
                    "Cannot remove the last game association and must transfer to another game"
            );
        }

        characters.remove(character);
    }
    void removeCharacterFromList(GameCharacter character){ //helper to remove char from game list(this)
        // called by GameCharacter.setGame() during a transfer.
        characters.remove(character);
    }
    public List<GameCharacter> getCharacters() {return new ArrayList<>(characters);}
    public String getName() {return name;}
    public String getGenre() {return genre;}
    public int getReleaseYear() {return releaseYear;}

    public void showCharacters() { //display game info and all associated characters
        System.out.println(name + " | Genre: " + genre +
                " | Year: " + releaseYear);

        for (GameCharacter character : characters) {
            System.out.println("  - " + character.getCharacterName());
        }
    }
    @Override
    public String toString(){
        return "Game: " + name + ", Genre: "+ genre + ", ReleaseYear: " + releaseYear +", Characters :" + characters;
    }

}


