package binary;

public class GameCharacter {

        private String CharacterName;
        private Game game; //impl. assoc. card. 1

        public GameCharacter(String CharacterName, Game game) { //constructor
        if (CharacterName == null || CharacterName.isBlank()) {
            throw new IllegalArgumentException("Name of a character is required");
        }
        if (game == null) {
            throw new IllegalArgumentException("Game is required");
        }
          this.CharacterName = CharacterName; //establishing the association and auto
          setGame(game);                      // auto updates games character list
    }

       public void setGame(Game game) { //automatically updates both sides of the association
            if (game == null){
                throw new IllegalArgumentException("Character must belong to a game");
            }
            if(this.game != game){ //prevents infinite recursion (unnecessary assoc. updates)
                Game oldGame = this.game; //save old game

                if(oldGame != null){ //remove char from old game
                    oldGame.removeCharacterFromList(this);
                }
                this.game = game; //establish new conncetion on 1 side
                game.addCharacter(this); //add char to new game
                                        // automatic reverse connection
            }
       }


   public Game getGame() {return game;}

    public String getCharacterName() {return CharacterName;}

    @Override
    public String toString(){
        return "GameCharacter: " + CharacterName + " , Game: "+ game.getName();
    }
}


