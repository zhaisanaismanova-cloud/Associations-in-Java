import binary.GameCharacter;
import withAttribute.*;
import binary.*;
import qualified.*;
import composition.*;


public class Main {
    public static void main(String[] args) {

        System.out.println("--------Binary association-------"); //binary association
        Game game1 = new Game("The Legend of Zelda: Breath of the Wild", "RPG", 2023);
        Game game2 = new Game("The Last of Us Part II", "Action", 2023);
        GameCharacter character1 = new GameCharacter("Princess Zelda", game1);
        GameCharacter character2 = new GameCharacter("Ellie Williams", game2);

        game1.showCharacters();
        game2.showCharacters();

        GameCharacter character3 = new GameCharacter("Link", game1); //add character

        System.out.println("\nafter adding new character:");
        game1.showCharacters();

        character1.setGame(game2); //move character to another game

        System.out.println("\nafter moving character Princess Zelda to game the Last of Us Part II:");
        game1.showCharacters();
        game2.showCharacters();

        character3.setGame(game2); //transfer character to another game, hence removing it from the first game

        System.out.println("\nafter removing character Link from The Legend of Zelda:");
        game1.showCharacters();

        System.out.println("------Association with an attribute-----"); //association with an attribute
        Client c1 = new Client("Sophia", "Richi", "123-456-7890");
        Client c2 = new Client("Anna","Mei","33333");
        Dentist d1 = new Dentist("Sparkle", "Smith", "Orthodontics");

        Appointment a1 = new Appointment(c1, d1, "2026-04-10", "10:00", "Cleaning", 80.0);
        Appointment a2 = new Appointment(c1, d1, "2026-05-12", "11:30", "Whitening", 150.0);
        Appointment a3 = new Appointment(c2, d1, "2026-06-01", "09:00", "Check-up", 60.0);
        // display appointments are stored on both sides
        System.out.println("\nClient c1 appointments: " + c1.getAppointments());
        System.out.println("Client c2 appointments: " + c2.getAppointments());
        System.out.println("Dentist appointments: " + d1.getAppointments());

        a1.delete(); //delete appointment1, auto remove from both lists

        System.out.println("\nAfter deleting appointment1:");
        System.out.println("Client c1 appointments: " + c1.getAppointments());
        System.out.println("Dentist appointments: " + d1.getAppointments());


        a2.delete(); //delete remaining appointments
        a3.delete();

        // Show that all appointment lists are now empty
        System.out.println("\nAfter deleting all appointments:");
        System.out.println("Client c1: " + c1.getAppointments().size());
        System.out.println("Client c2: " + c2.getAppointments().size());
        System.out.println("Dentist: " + d1.getAppointments().size());

        System.out.println("\nAfter adding a new appointment:");
        Appointment a4 = new Appointment(
                c1, d1, "2026-07-10", "12:00", "Check-up", 60.0
        );

        // Show that the new appointment appears on both sides
        System.out.println("Client c1 appointments: " + c1.getAppointments());
        System.out.println("Dentist appointments: " + d1.getAppointments());

        System.out.println("--------Qualified association--------"); //qualified association
        Country poland = new Country("PL","Poland",15.50); //create countries
        Country germany = new Country("DE","Germany",10.00);
        System.out.println("Countries: " + poland + " | " + germany);
        Customer customer1 = new Customer("Alisa"); //create customers
        Customer customer2 = new Customer("John");
        System.out.println("Customers: " + customer1 + " | " + customer2);

        customer1.addCountriesQualif(poland); //add countries to customer
        customer2.addCountriesQualif(germany);
        System.out.println("\nCustomers added:");
        System.out.println("Poland: " + poland.getCustomers()); //display customers
        System.out.println("Germany: " + germany.getCustomers());

        Country found = customer1.findCountriesQualif("PL"); // Find country using qualifier
        System.out.println("Found country by qualifier: " + found);

        System.out.println("\nAlisa shipping to Poland: "
                + customer1.calculateShippingCost("PL")); //calculate shipping cost

        customer2.removeCountriesQualif("DE"); //remove country from customer
        customer1.addCountriesQualif(poland); //add new country to customer
        System.out.println("\nAfter moving John to Poland:");
        System.out.println("Poland: " + poland.getCustomers());
        System.out.println("Germany: " + germany.getCustomers());



        System.out.println("-----------Composition------------"); //composition

        Contest contest = new Contest("Talent Show");
        System.out.println("Contest: " + contest);

        Contestant contestant1 = contest.addContestant("Anna", 20); //create and add contestant
        Contestant contestant2= contest.addContestant("Mark", 22);


        System.out.println("\nContest: " + contest.getName());   // display contest and its associated contestants
        System.out.println("After adding contestants:");
        System.out.println(contest.getContestants());

        contest.removeContestant(contestant2); //removing contestant2

        System.out.println("\nAfter removing :");
        System.out.println("Contest: " + contest.getName());
        System.out.println(contest.getContestants());


        contest.deleteAllContestants(); //deleting contests remaining parts

        System.out.println("\nAfter deleting contest:");
        System.out.println("Contest:" + contest.getName());
        System.out.println(contest.getContestants());

    }
}