package withAttribute;

public class Appointment {

    private Client client; //referencing 2 objects
    private Dentist dentist;

    private String date; //attributes describing relationship between 2 objects
    private String time;
    private String treatmentType;
    private double price;

    public Appointment(Client client, Dentist dentist, //creates an appointment, get 2 objects info about appointment
                       String date, String time,
                       String treatmentType, double price) {
        if (client == null || dentist == null)
            throw new IllegalArgumentException("Client and Dentist required");

        if (date == null || time == null || treatmentType == null)
            throw new IllegalArgumentException("Invalid appointment data");

        this.client = client; //store the ref. to connected objs
        this.dentist = dentist;
        this.date = date;
        this.time = time;
        this.treatmentType = treatmentType;
        this.price = price;


        client.addAppointment(this); //establish reverse connection
        dentist.addAppointment(this); //adding appointment to 2 objects' lists'
    }


    public Client getClient() {return client;}

    public Dentist getDentist() {return dentist;}

    public String getTreatmentType() {return treatmentType;}

    public double getPrice() {return price;}

    @Override
    public String toString() {
        return client + " → " + treatmentType +
                " with " + dentist +
                " on " + date + " " + time +
                " ($" + price + ")";
    }
    public void delete() { //deletes appointment from both objects' lists
        client.removeAppointment(this);
        dentist.removeAppointment(this);
    }
}