package withAttribute;

import java.util.ArrayList;
import java.util.List;

public class Dentist {

    private String name;
    private String surname;
    private String specialization;

    private List<Appointment> appointments = new ArrayList<>(); //stores all appointments belonging to this dentist

    public Dentist(String name, String surname, String specialization) {
        validate(name);
        validate(surname);
        validate(specialization);

        this.name = name;
        this.surname = surname;
        this.specialization = specialization;
    }

    private void validate(String value) {
        if (value == null || value.isEmpty())
            throw new IllegalArgumentException("Invalid value");
    }

    public void addAppointment(Appointment a) { //add appointment to dentist's list
        if (a == null) throw new IllegalArgumentException("Appointment cannot be null");
        if (!appointments.contains(a))
         appointments.add(a);
    }

    public void removeAppointment(Appointment a) { //remove appointment from dentist's list'
        if (a == null) return;
        appointments.remove(a);
    }

    public List<Appointment> getAppointments() {
        return new ArrayList<>(appointments);
    } //returned dentist's appointments, new list is returned

    public String getName() { return name; }
    public String getSurname() { return surname; }
    public String getSpecialization() { return specialization; }

    @Override
    public String toString() {
        return "Dr. " + name + " " + surname;
    }
}