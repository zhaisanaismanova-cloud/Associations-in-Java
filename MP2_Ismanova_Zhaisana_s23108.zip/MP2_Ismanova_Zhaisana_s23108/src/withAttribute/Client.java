package withAttribute;

import java.util.ArrayList;
import java.util.List;

public class Client {

    private String name;
    private String surname;
    private String phoneNumber;

    private List<Appointment> appointments = new ArrayList<>(); //stores all appointments belonging to this client

    public Client(String name, String surname, String phoneNumber) {
        validate(name);
        validate(surname);
        validate(phoneNumber);

        this.name = name;
        this.surname = surname;
        this.phoneNumber = phoneNumber;
    }

    private void validate(String value) {
        if (value == null || value.isEmpty())
            throw new IllegalArgumentException("Invalid value");
    }


    public void addAppointment(Appointment a) {  //add appointment to client's list'
        if (a == null) throw new IllegalArgumentException("Appointment cannot be null");
        if (!appointments.contains(a))
            appointments.add(a);
    }

    public void removeAppointment(Appointment a) { //remove appointment from client's list'
        if (a == null) return;
        appointments.remove(a);
    }

    public List<Appointment> getAppointments() {
        return new ArrayList<>(appointments);
    } //returned client's appointments, new list is returned

    public String getName() { return name; }
    public String getSurname() { return surname; }
    public String getPhoneNumber() { return phoneNumber; }

    @Override
    public String toString() {
        return name + " " + surname;
    }
}