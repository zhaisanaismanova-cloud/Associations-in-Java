package composition;

public class Contestant {

    private String name;
    private int age;

    private Contest contest;  //impl. assoc. card. 1

    Contestant(String name, int age, Contest contest) { // to be called only by Contest

        if (contest == null) //contestant cannot be created without a contest
            throw new IllegalArgumentException("Contest required");

        this.name = name;
        this.age = age;
        this.contest = contest;  //reverse association
    }

    public Contest getContest() {
        return contest;
    } //allows nav from contestant to contest

    @Override
    public String toString() {
        return name + " (" + age + ")";
    }
}

