package composition;

import java.util.HashSet;
import java.util.Set;


public class Contest {

    private String name;

    private static Set<Contestant> allContestants = new HashSet<>(); //store all contestants, belongs to class itself

    private Set<Contestant> contestants = new HashSet<>(); //impl. assoc. card. *

    public Contest(String name) {
        if (name == null || name.isEmpty()) throw new IllegalArgumentException("Name required");
        this.name = name;
    }

    public Contestant addContestant(String name, int age) { //add contestant and
        Contestant c = new Contestant(name, age, this);  //establish reverse connection

        contestants.add(c); //adds contestant to the Contest collection
        allContestants.add(c); //register contestant in static collection

        return c;
    }

    public void removeContestant(Contestant c) { //remove contestant from this contest
        if (c == null) return;

        contestants.remove(c); //removes contestant from the Contest collection
        allContestants.remove(c);
    }

    public void deleteAllContestants() { //remove all contestants from this contest
        for (Contestant c : contestants) { //removes each contestant from the Contest collection
            allContestants.remove(c);
        }
        contestants.clear();
    }
    public String getName() {
        return name;
    }

    public Set<Contestant> getContestants() {
        return new HashSet<>(contestants);
    } //returns a copy of the collection
    @Override
    public String toString() {
        return name;
    }


}
